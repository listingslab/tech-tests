This is [candidate] coding submission

**Submission running**
[add a gif here]

**Test evaluation suite**
[add screenshots or merge in the evaluateSolutionDescription branch so we can see the tests run in BuildKite]
